## Font Awesome

Copyright (C) 2016-2021 by Dave Gandy

- Author:    Dave Gandy
- License:   SIL (https://fontawesome.com/license/free) 
- Homepage:  https://fontawesome.com/

### Note on Brand Icons

All brand icons are trademarks of their respective owners.
The use of these trademarks does not indicate endorsement of the trademark holder by Font Awesome, nor vice versa.
Brand icons should only be used to represent the company or product to which they refer.
Please do not use brand logos for any purpose except to represent that particular brand or service.
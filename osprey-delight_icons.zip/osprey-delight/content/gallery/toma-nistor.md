---
weight: 30
date: "2017-05-15T20:00:16-07:00"
title: "Toma Nistor"
image: "toma-nistor.png"
alt: "Toma Nistor"
color: "#212121"
buttons:
  - i18n: view
    url: "https://tomanistor.com"
  - i18n: code
    url: "https://github.com/tomanistor/tomanistor.com"
---

Author of the original Osprey theme.
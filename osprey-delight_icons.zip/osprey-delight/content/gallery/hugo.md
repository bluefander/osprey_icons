---
weight: 10
date: "2017-05-12T22:25:02-07:00"
title: "Hugo"
image: "hugo.png"
alt: "Hugo - a fast and modern static website engine"
color: "#0a1922"
buttons:
  - icon: gift 
    i18n: download 
    url: https://gohugo.io/
  - icon: code
    i18n: code
    url: "https://github.com/spf13/hugo"
---

Hugo is one of the most popular open-source static site generators. 
With its amazing speed and flexibility, Hugo makes building websites fun again.
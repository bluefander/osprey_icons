---
weight: 10
date: "2019-05-17T22:25:16-07:00"
title: "KDEVO"
image: "kd.png"
alt: "kdevo"
color: "#263238"
buttons:
  - i18n: view
    url: "https://kdevo.github.io"
  - i18n: code 
    url: "https://github.com/kdevo/"
---

Author of Osprey Delight.
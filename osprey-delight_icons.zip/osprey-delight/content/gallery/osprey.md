---
weight: 40
date: "2017-05-15T21:57:17-07:00"
title: "Osprey"
image: "osprey-logo.png"
color: "#F7F7F7"
type: "github"
github:
    repo: "tomanistor/osprey"
    showInfo: true
---

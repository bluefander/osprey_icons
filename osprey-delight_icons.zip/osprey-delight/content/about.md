+++
title = "About"
date = "2017-06-27T17:39:21-07:00"
draft = false
+++

Osprey Delight is the free-minded artist's choice for a clutter-free and fast single-page portfolio. 

It tastes a bit different than [the original great Osprey theme](https://github.com/tomanistor/osprey) and adds awesome new functionality to your Delight.

It's perfectly suited to show off your awesome work! {{< icon "rocket icon-pulse-fast" >}}
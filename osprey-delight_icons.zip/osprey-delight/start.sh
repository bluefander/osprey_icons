#!/bin/bash

set -e

cd exampleSite/
hugo server --themesDir ../../ 
cd ..

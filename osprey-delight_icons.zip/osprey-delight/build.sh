#!/bin/bash

set -ev

cd exampleSite/
hugo --themesDir ../../
cd ..
